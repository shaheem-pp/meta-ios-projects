//
//  SwiftUIView.swift
//  Little Lemon Menu
//
//  Created by Shaheem PP on 22/02/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
