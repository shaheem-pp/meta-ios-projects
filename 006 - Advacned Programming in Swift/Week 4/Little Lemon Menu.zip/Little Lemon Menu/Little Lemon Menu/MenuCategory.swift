//
//  MenuCategory.swift
//  Little Lemon Menu
//
//  Created by Shaheem PP on 22/02/24.
//

import Foundation


enum MenuCategory : String{
    case Food
    case Drink
    case Dessert
}
