//
//  Ingredient.swift
//  Little Lemon Menu
//
//  Created by Shaheem PP on 22/02/24.
//

import Foundation

enum Ingredient : String{
    case Spinach
    case Broccoli
    case Carrot
    case Pasta
    case Tomatosauce
}
