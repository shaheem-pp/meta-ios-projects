//
//  Little_LemonApp.swift
//  Little Lemon
//
//  Created by Shaheem PP on 10/12/23.
//

import SwiftUI

@main
struct Little_LemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
